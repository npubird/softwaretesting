# box-black-box
Testing tests for overlapping box problem with various algorithms

Live version can be found at http://thullsl.github.io/box-black-box/
